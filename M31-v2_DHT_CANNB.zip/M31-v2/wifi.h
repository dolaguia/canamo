#include "ESP8266WiFi.h"

WiFiClient espClient;

//wifi
char ssid[] = SECRET_SSID;
char pass[] = SECRET_PASS;

void setup_wifi()
{
  int contadorWIFI = 0;
  delay(10);
  WiFi.setOutputPower(20);
  WiFi.mode(WIFI_STA);
//  WiFi.config(ip, gateway, subnet);
  Serial.println();
  Serial.println("\nMAC Address: " + WiFi.macAddress());
  Serial.print("Conectando a ");
  Serial.println(SECRET_SSID);

  WiFi.begin(ssid, pass);

  while (WiFi.status() != WL_CONNECTED)
  {
    WiFi.begin(ssid, pass);
    Serial.print(".");
    contadorWIFI = contadorWIFI + 1;
    if (contadorWIFI > 1000)
    {
      Serial.println("Sin WIFI. Reiniciando...");
      ESP.restart();
    }
    delay(5000);
  }

  Serial.println("");
  Serial.println("WiFi conectado.");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  contadorWIFI = 0;
}
