/*
 * Configuración HardwareArdora Modelo A (M31-V2)
 */

#define DHT_TYPE    DHT22 
#define DHT_PIN     0                     // GPIO0. D3
#define ONEWIRE_PIN 0                     // GPIO0.
#define TRIG_PIN    1                     // GPIO1/TXD: ARDORA-A
#define ECHO_PIN    3                     // GPIO3/RXD: ARDORA-A
#define RAIN_PIN    3
#define FLUX_PIN    3                     // GPIO3. ARDORA-A: Pulso caudalímetro entra por puerto ECHO
#define PULSOS_POR_LITRO 373.5  // Valor medido

