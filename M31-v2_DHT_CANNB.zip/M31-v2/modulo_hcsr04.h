#ifdef SENSOR_NIVEL

#define ALTURA_SENSOR 29.0    //Para EGG01.1 es 28.0
#define LITROS_POR_CM 1.4285  //Para EGG01.1
#define CAPACIDAD_TANQUE 40.0 //Para EGG01.1 (en litros)

void setup_nivel() {
  pinMode(1, FUNCTION_3);     // GPIO 1 (TX): cambiar la función del pin a GPIO. Se deshace con FUNCTION_0 *
  pinMode(3, FUNCTION_3);     // GPIO 3 (RX): cambiar la función del pin a GPIO. Se deshace con FUNCTION_0 *
  pinMode(TRIG_PIN, OUTPUT);   
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW); 
}

long obtenerDuracion() {
  // lectura de distancia
  // Clears the trigPin for 2 microseconds
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  // Sets the trigPin on HIGH state for 10 microseconds. Es decir, envía un pulso de 10uS
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  // Reads the echoPin, returns the sound wave travel time in microseconds. Es decir mide el tiempo que tarda en retornar en uS
  long duration = pulseIn(ECHO_PIN, HIGH); 
  return duration;
}

float obtenerDistancia(long duration) {
  float distance = duration * 0.017;    // Distancia = duración(s) * vel_sonido(m/s) / 2 = 10^-6 * duracion(us) * 100 * vel_sonido(cm/us) / 2
                                        // = duracion(uS)*vel_sonido(cm/s) = 10^-4 * 340 / 2 * duracion(uS) = 0.017 duracion (uS)
  return distance;
}

float obtenerLitros(long distance) {
  // El tanque tiene una capacidad de 1.4285 litros por cm
  // el sensor esta ubicado a 9cm del limite maximo de carga
  // la capacidad del tanque es de 40 litros. 
  // altura_tanque = 40/1.4285 = 28 cm 
  
  float alturaSensor = ALTURA_SENSOR;
  float litrosPorCm = LITROS_POR_CM;                              // Válido para tanque EGG 
  float litros = (alturaSensor - float (distance))*litrosPorCm;   // Para un tanque
  return litros;
}

float obtenerPorcentajeLlenado(float litros) {
  float capacidad = CAPACIDAD_TANQUE;
  float porcentaje = litros * 100 / capacidad;
  return porcentaje;
}

float obtenerNivel(long distance) {
  float alturaSensor = ALTURA_SENSOR;
  //float nivel = ((28.0-9.0) - distance) * 0.017; 
  float nivel = (alturaSensor - float(distance)) * 0.017;  
  return nivel;
}

#endif


// (*) https://arduino.stackexchange.com/questions/29938/how-to-i-make-the-tx-and-rx-pins-on-an-esp-8266-01-into-gpio-pins
