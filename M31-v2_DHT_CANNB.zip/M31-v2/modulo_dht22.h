/*
 * Módulo: modulo_dht22.h
 * 
 * 26/08/2023
*/

#ifdef SENSOR_TEMPHUM

  #include "DHT.h"
  
  #define DHTTYPE DHT22

  //extern unsigned long tiempoUltimaLectura;   // la variable global está en otro módulo (el .ino)
  float temperatura = 0;
  float humedad = 0;
  const int DHTPin = DHT_PIN; 
  DHT dht(DHTPin, DHTTYPE); 
  
  void setup_DHT22()
  {
    dht.begin();
  }
  
  float obtenerTemperatura_DHT22(){
    unsigned long tiempoUltimaLectura;
    tiempoUltimaLectura = millis() + 2000;
    while(millis() < tiempoUltimaLectura){
      Serial.print("t  ");
    }
    Serial.println(" ");
    
    temperatura = dht.readTemperature();
    //Serial.println("Temperatura: " + String(temperatura));
    return temperatura;

  }
  
  float obtenerHumedad_DHT22(){
    unsigned long tiempoUltimaLectura;
    tiempoUltimaLectura = millis() + 2000;
    while(millis() < tiempoUltimaLectura){
      Serial.print("h  ");
    }
    Serial.println(" ");

    humedad = dht.readHumidity();
    //Serial.println("Humedad: " + String(humedad));
    return humedad; 
  }

#endif
