#define SECRET_SSID "Cañamo Sur"
#define SECRET_PASS "Canamo2023"


//#define SECRET_SSID "CASA2"
//#define SECRET_PASS "Danmar13"

//#define SECRET_SSID "sspedruzco"
//#define SECRET_PASS "podrido4lcuadrado"

//#define SECRET_SSID "CABLE10 35722"
//#define SECRET_PASS "beecher1276"

//#define SECRET_SSID "CAMPUS"
//#define SECRET_PASS "CAMPUSUARG"
