#ifdef SENSOR_TEMP_LIQUIDO

  #include <OneWire.h>                                  
  #include <DallasTemperature.h> 
  
  void setup_temp_liquido() {
                                              //  No va nada    
  }
  
  
  float obtenerTempLiquido() {
    OneWire ourWire(ONEWIRE_PIN);             // 
    DallasTemperature sensors(&ourWire);          // Se declara un objeto para el sensor 
    sensors.requestTemperatures();                // Se envía el comando para leer la temperatura
    float templiq = sensors.getTempCByIndex(0);   // Se obtiene la temperatura en ºC (0)
  
    //Serial.print("Temperatura= ");          //
    //Serial.print(temp);                     //
    //Serial.println(" C");                   //
    //delay(1000);                            //
  
    return templiq;
  }
#endif
