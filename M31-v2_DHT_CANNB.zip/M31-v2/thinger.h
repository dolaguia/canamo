// usuario
#define USERNAME "barbara"

// dispositivos
#define DEVICE_ID "CNBTYH01"
#define DEVICE_CREDENTIAL "lzs18DBY26LCxb9$"

