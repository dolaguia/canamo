#ifdef SENSOR_LLUVIA 

bool lluvia;
unsigned char sensorLluvia = RAIN_PIN; 

void setup_lluvia() {
  pinMode(sensorLluvia, INPUT);
}

bool lectura_lluvia() {
  lluvia = digitalRead(sensorLluvia);
  return lluvia;
}

#endif 
