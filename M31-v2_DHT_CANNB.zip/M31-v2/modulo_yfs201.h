/*
 * Módulo: modulo_yfs201.h
 * Caudalímetro tipo YF-S201: 400 pulsos por litro nominales
 * 26/08/2023
*/

#ifdef SENSOR_CAUDAL 

  #define PULSOS_POR_LITRO 373.5  // Valor medido
  
  unsigned char sensorDeFlujo = FLUX_PIN;   // 3.   Pin de entrada de señal de caudalímetro   
  volatile int pulsos;                      // Pulsos del caudalímetro contados entre mediciones. Como se usa dentro de una interrupcion debe ser volatile
  float litros;                             // Litros acumulados
  float litrosPorHora;                      // Litros/hora calculados
  float pulsosPorHora;                      // Pulsos/hora calculados
  float diferenciaVolumen;                  // Diferencia de volumen calculada
  unsigned long tiempoAnterior;             // Marca de tiempo
  unsigned long diferenciaTiempo;           // Diferencia de tiempo medida entre mediciones del sensor. Expresada en milisegundos.  /  unsigned long pulsosAcumulados;           // Pulsos acumulados
  unsigned long diferenciaPulsos;           // Diferencia de pulsos desde la última medición
  unsigned long pulsosAcumulados;
  
  // VARIABLES GLOBALES
  extern float totalLitros;
  extern unsigned long periodo;
  extern int pulsosPeriodo;
  extern float volumen;
  extern float lxh; 

  void IRAM_ATTR flujo();         // Prototipo ISR/callback
  
  
  void IRAM_ATTR flujo()          // ISR/callback
  {
    pulsos++; // Incrementar el numero de pulsos
  }
  
  void setup_YFS201() {
   
    // pinMode(sensorDeFlujo, FUNCTION_3);     // GPIO 3 (RX): cambiar función original del pin a GPIO. Se puede deshacer con FUNCTION_0
    pinMode(sensorDeFlujo, INPUT);
    attachInterrupt(digitalPinToInterrupt(sensorDeFlujo),flujo, RISING);
    interrupts(); 
    
    tiempoAnterior = millis();
    diferenciaTiempo = 1000;
    diferenciaVolumen = 0;
    diferenciaPulsos = 0;
    pulsosPorHora = 0.0;
    litrosPorHora = 0.0;
    pulsosAcumulados = 0;
    litros = 0.0;  
  }
  
  void lectura_YFS201() {
    float pulsosPorLitro = PULSOS_POR_LITRO;

    diferenciaTiempo = millis() - tiempoAnterior; // Diferencia entre tiempo actual y tiempo de última medición.  // Se publica (Principal)
      periodo = diferenciaTiempo;     // es lo mismo que diferenciaTiempo pero variable global
    diferenciaPulsos = pulsos;  
      pulsosPeriodo = pulsos;         // idem pero con diferenciaPulsos
    diferenciaVolumen =  float(diferenciaPulsos)/pulsosPorLitro;                                                  // Se publica (Principal)
      volumen = diferenciaVolumen;
    pulsosPorHora = 3600.0 * 1000.0 * (float(diferenciaPulsos)/float(diferenciaTiempo)); 
    litrosPorHora = pulsosPorHora/pulsosPorLitro;                                                                 // Se publica (Secundario)
      lxh = litrosPorHora;
    pulsosAcumulados = pulsosAcumulados + pulsos;                                                                 // Se publica (Secundario)                    
    litros = float(pulsosAcumulados)/pulsosPorLitro;                                                              // Se publica (Secundario)                                                   
      totalLitros = litros;  
    tiempoAnterior = millis();  
                      // Tomar el tiempo actual y guardarlo para la próxima medición
    pulsos = 0;  
  }

#endif 
