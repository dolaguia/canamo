/* Constantes del sistema */
#define ID_PROYECTO "MAPHI"
#define ID_SENSOR "M31-v2"
#define RETARDO_LOOP  30000

/* Definiciones para compilación condicional*/
#define COM_WIFI            //Comunicación wifi

#define SENSOR_TEMPHUM      //Sensor de Temperatura y Humedad DHT22
//#define SENSOR_NIVEL      //Sensor ultrasónico HSCR04
//#define SENSOR_CAUDAL       //Sensor de caudal YF-S201
//#define SENSOR_TEMP_LIQUIDO
//#define SENSOR_LLUVIA
